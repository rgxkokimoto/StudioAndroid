package com.dam.armoniaskills.model;

public enum StatusCompraEnum {
	PENDIENTE, ACEPTADO, RECHAZADO, ENVIADO, COMPLETADO
}
