# Armonia Bills
## Aplicación Android

Armonia Bills es una aplicación para Android para compartir gastos con backend Firebase.

## Tabla de Contenidos

- [Descripción del proyecto](#descripción-del-proyecto)
- [Funcionalidades principales](#funcionalidades-principales)

## Descripción del proyecto

Armonía Bills utiliza como backend Firebase y varios de los servicios que ofrece como Real Time Storage para guardar los datos de cada usuario y Authentication para gestionar la creación de cuentas.

## Funcionalidades principales

Los usuarios crean grupos y añaden a otros usuarios. Cada usuario puede crear nuevos gastos y decidir como se reparten. A cada usuario despues le aparece exactamente cuanto debe y puede pagarlo con una cartera virtual.
